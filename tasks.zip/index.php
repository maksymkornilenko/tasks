<?php

require_once ('conf/config.php');
